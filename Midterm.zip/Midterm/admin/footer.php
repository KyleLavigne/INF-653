<nav>
<a href="index.php">Vehicles</a> |
<a href="add_vehicle.php">Add</a> |
<a href="manage_makes.php">Makes</a> |
<a href="manage_types.php">Types</a> |
<a href="manage_classes.php">Classes</a>
</nav>